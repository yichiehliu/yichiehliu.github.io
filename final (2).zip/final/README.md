## 製作踩地雷遊戲

### 讀取Cookie
**https://www.fooish.com/javascript/cookie.html**
